extern double Chp[2];
extern int Ichp[2]; 
