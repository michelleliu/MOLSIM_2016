int NumberOfCycles;
int NumberOfSteps;
double Tstep;
double Temperature;
double Xpos;
double Vpos;
double Theta;
double Qstar;
