#include "system.h"

VECTOR Positions[MAX_NUMBER_OF_PARTICLES];
VECTOR OldPositions[MAX_NUMBER_OF_PARTICLES];
int NumberOfParticles;
