#include "system.h"

VECTOR Positions[MAX_PARTICLES];
int NumberOfParticles;

